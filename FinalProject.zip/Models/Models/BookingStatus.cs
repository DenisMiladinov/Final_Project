namespace Models;

public enum BookingStatus
{
    Pending,
    Confirmed,
    Cancelled
}