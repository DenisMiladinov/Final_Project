﻿namespace Models.ViewModels
{
    public class AdminDashboardViewModel
    {
        public int TotalBookings { get; set; }
        public int TotalUsers { get; set; }
        public int TotalSpots { get; set; }
    }
}
