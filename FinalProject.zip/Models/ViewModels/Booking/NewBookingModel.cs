﻿namespace Server.Models.Booking
{
    public class NewBookingModel
    {
    }
}
